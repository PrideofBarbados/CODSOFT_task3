import streamlit as st
import  pandas as pd
import numpy as np
import pickle
from sklearn.tree import DecisionTreeRegressor


pickle_in = open('DecisionTreeRegressor.pkl', 'rb')
model = pickle.load(pickle_in)


sales_df = pd.read_csv('advertising (1).csv')

## creation of streamlit app
st.title('ADVERTISEMENT SALES PREDICTION')

TV = st.number_input('Enter Amount For TV: ', key=1)
Radio = st.number_input('Enter Amount For Radio: ', key=2)
Newspaper = st.number_input('Enter Amount For Newspaper: ', key=3)

prediction = model.predict([[TV, Radio, Newspaper]])
if st.button('Predict'):
    prediction